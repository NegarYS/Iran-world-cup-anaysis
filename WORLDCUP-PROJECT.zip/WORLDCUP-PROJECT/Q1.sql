SELECT TM.team_id , TM.team_name , T.tournament_id , T.year , GS.goals_for , GS.goals_against ,
       GS.goal_difference, GS.wins , GS.losses, GS.draws , GS.points , GS.played
FROM teams TM INNER JOIN group_standings GS ON GS.team_id = TM.team_id
	          INNER JOIN tournaments T ON T.tournament_id = GS.tournament_id
			  
WHERE TM.team_name = 'Iran'
ORDER BY T.year
