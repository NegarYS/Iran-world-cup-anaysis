WITH TeamStats AS
(
    SELECT tournament_id,team_id,        
        SUM(
            CASE
                WHEN win = 1 THEN 3
                WHEN draw = 1 THEN 1
                ELSE 0
            END
        ) AS points,

        SUM(goal_differential) AS goal_difference,

        SUM(goals_for) AS goals_for,
        SUM(goals_against) AS goals_against

    FROM team_appearances
    GROUP BY tournament_id, team_id
),

IranOpponents AS
(
    SELECT DISTINCT tournament_id,opponent_id
    FROM team_appearances
    WHERE team_id = 'T-38'
),

IranOpponentStrength AS
(
    SELECT IO.tournament_id,       
        AVG(CAST(TS.points AS FLOAT)) AS avg_opponent_points,
        AVG(CAST(TS.goal_difference AS FLOAT)) AS avg_opponent_gd,
        AVG(CAST(TS.goals_for AS FLOAT)) AS avg_opponent_gf,
        AVG(CAST(TS.goals_against AS FLOAT)) AS avg_opponent_ga

    FROM IranOpponents IO INNER JOIN TeamStats TS        
            ON IO.tournament_id = TS.tournament_id
           AND IO.opponent_id = TS.team_id

    GROUP BY IO.tournament_id
),

TournamentAverage AS
(
    SELECT tournament_id,       
        AVG(CAST(points AS FLOAT)) AS avg_tournament_points,
        AVG(CAST(goal_difference AS FLOAT)) AS avg_tournament_gd,
        AVG(CAST(goals_for AS FLOAT)) AS avg_tournament_gf,
        AVG(CAST(goals_against AS FLOAT)) AS avg_tournament_ga

    FROM TeamStats
    GROUP BY tournament_id
)

SELECT IOS.tournament_id,IOS.avg_opponent_points,TA.avg_tournament_points,
       IOS.avg_opponent_gd,TA.avg_tournament_gf,
       IOS.avg_opponent_ga,TA.avg_tournament_ga
    

FROM IranOpponentStrength IOS INNER JOIN TournamentAverage TA
              ON IOS.tournament_id = TA.tournament_id
ORDER BY IOS.tournament_id;