WITH T 
AS
(SELECT * , COUNT(goal_id)OVER(PARTITION BY CASE
                                                 WHEN minute_regulation BETWEEN 1 AND 15 THEN '01-15'
                                                 WHEN minute_regulation BETWEEN 16 AND 30 THEN '16-30'
                                                 WHEN minute_regulation BETWEEN 31 AND 45 THEN '31-45'
                                                 WHEN minute_regulation BETWEEN 46 AND 60 THEN '46-60'
                                                 WHEN minute_regulation BETWEEN 61 AND 75 THEN '61-75'
                                                 ELSE '76-90'
											END) AS scores , 
          CASE
             WHEN minute_regulation BETWEEN 1 AND 15 THEN '01-15'
             WHEN minute_regulation BETWEEN 16 AND 30 THEN '16-30'
             WHEN minute_regulation BETWEEN 31 AND 45 THEN '31-45'
             WHEN minute_regulation BETWEEN 46 AND 60 THEN '46-60'
             WHEN minute_regulation BETWEEN 61 AND 75 THEN '61-75'
             ELSE '76-90'
		  END AS quarter_minutes
FROM goals
WHERE team_id = 'T-38'
),
T1
AS 
(SELECT G.goal_id ,G.minute_regulation, G.team_id, 
        COUNT(goal_id)OVER(PARTITION BY  CASE
                                            WHEN minute_regulation BETWEEN 1 AND 15 THEN '01-15'
                                            WHEN minute_regulation BETWEEN 16 AND 30 THEN '16-30'
                                            WHEN minute_regulation BETWEEN 31 AND 45 THEN '31-45'
                                            WHEN minute_regulation BETWEEN 46 AND 60 THEN '46-60'
                                            WHEN minute_regulation BETWEEN 61 AND 75 THEN '61-75'
                                            ELSE '76-90'
		                                 END ) AS Conceded ,  
        CASE
             WHEN minute_regulation BETWEEN 1 AND 15 THEN '01-15'
             WHEN minute_regulation BETWEEN 16 AND 30 THEN '16-30'
             WHEN minute_regulation BETWEEN 31 AND 45 THEN '31-45'
             WHEN minute_regulation BETWEEN 46 AND 60 THEN '46-60'
             WHEN minute_regulation BETWEEN 61 AND 75 THEN '61-75'
             ELSE '76-90'
		END AS quarter_minutes
FROM goals G INNER JOIN team_appearances TA ON  G.team_id = TA.opponent_id AND G.match_id = TA.match_id  AND G.tournament_id = TA.tournament_id
WHERE TA.team_id = 'T-38'
)

SELECT  DISTINCT T1.quarter_minutes ,T.scores,T1.Conceded
FROM T FULL JOIN T1 ON T.quarter_minutes = T1.quarter_minutes

