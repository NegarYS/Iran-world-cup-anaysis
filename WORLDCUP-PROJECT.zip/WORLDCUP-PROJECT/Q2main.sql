WITH TeamStrength AS
(
    SELECT tournament_id, team_id, SUM(CASE
                                          WHEN win = 1 THEN 3
                                          WHEN draw = 1 THEN 1
                                          ELSE 0
                                       END
                                       ) AS points,

        SUM(goals_for) AS goals_for,
        SUM(goals_against) AS goals_against,
        SUM(goal_differential) AS goal_diff,
        SUM(CONVERT(INT, win)) AS wins

    FROM team_appearances
    GROUP BY tournament_id, team_id
),
IranOpponents AS
(
    SELECT DISTINCT tournament_id,opponent_id
    FROM team_appearances
    WHERE team_id = 'T-38'
),

OpponentStrength AS
(
    SELECT IO.tournament_id,AVG(CAST(TS.points AS FLOAT)) AS opp_avg_points,
                            AVG(CAST(TS.goals_for AS FLOAT)) AS opp_avg_goals_for,
                            AVG(CAST(TS.goals_against AS FLOAT)) AS opp_avg_goals_against,
                            AVG(CAST(TS.goal_diff AS FLOAT)) AS opp_avg_goal_diff,
                            AVG(CAST(TS.wins AS FLOAT)) AS opp_avg_wins
        
    FROM IranOpponents IO INNER JOIN TeamStrength TS
                       ON IO.opponent_id = ts.team_id AND IO.tournament_id = ts.tournament_id
                       
    GROUP BY IO.tournament_id
),

TournamentAverage AS
(
    SELECT tournament_id,AVG(CAST(points AS FLOAT)) AS tournament_avg_points,
                         AVG(CAST(goals_for AS FLOAT)) AS tournament_avg_goals_for,
                         AVG(CAST(goals_against AS FLOAT)) AS tournament_avg_goals_against,
                         AVG(CAST(goal_diff AS FLOAT)) AS tournament_avg_goal_diff,
                         AVG(CAST(wins AS FLOAT)) AS tournament_avg_wins
   
    FROM TeamStrength
    GROUP BY tournament_id
)

SELECT O.tournament_id,
    ROUND(O.opp_avg_points,2)   AS opp_avg_points,
    ROUND(T.tournament_avg_points,2) AS tournament_avg_points,

    ROUND(O.opp_avg_goals_for,2)        AS opp_avg_goals_for,
    ROUND(T.tournament_avg_goals_for,2) AS tournament_avg_goals_for,

    ROUND(O.opp_avg_goals_against,2)        AS opp_avg_goals_against,
    ROUND(T.tournament_avg_goals_against,2) AS tournament_avg_goals_against,

    ROUND(O.opp_avg_wins,2)        AS opp_avg_wins,
    ROUND(T.tournament_avg_wins,2) AS tournament_avg_wins

FROM OpponentStrength O  INNER JOIN TournamentAverage T ON O.tournament_id = T.tournament_id  
ORDER BY O.tournament_id