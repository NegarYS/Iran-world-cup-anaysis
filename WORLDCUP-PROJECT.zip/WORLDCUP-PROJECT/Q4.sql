SELECT team_id,
       COUNT(*) AS appearances,
       SUM(convert(int,advanced)) AS advanced_count,
	   SUM(points) AS SUM_points,
       SUM(goals_for * 1.0) AS SUM_goals_for,
       SUM(goals_against * 1.0) AS SUM_goals_against,
       SUM(goal_difference * 1.0) AS SUM_goal_diff,
       AVG(points * 1.0) AS avg_points,
       AVG(goals_for * 1.0) AS avg_goals_for,
       AVG(goals_against * 1.0) AS avg_goals_against,
       AVG(goal_difference * 1.0) AS avg_goal_diff
FROM group_standings
WHERE team_id IN (SELECT team_id FROM teams WHERE team_name IN ('Iran' , 'Japan' , 'South Korea') )
GROUP BY team_id

