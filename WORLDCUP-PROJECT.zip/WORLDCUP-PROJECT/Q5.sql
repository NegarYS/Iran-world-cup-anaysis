WITH IranMatches 
AS
(SELECT TA.tournament_id,TA.match_id,M.match_name,TA.result,TA.goals_for,
        TA.goals_against,TA.goal_differential,CASE
                                                  WHEN TA.win = 1 THEN 3
                                                  WHEN TA.draw = 1 THEN 1
                                                  ELSE 0
                                               END AS MatchPoints
        
FROM team_appearances  TA INNER JOIN matches M ON TA.match_id = M.match_id
WHERE team_id = 'T-38'
)

SELECT *, RANK() OVER(ORDER BY MatchPoints DESC,goal_differential DESC) AS MatchRank                
FROM IranMatches 
ORDER BY MatchRank;